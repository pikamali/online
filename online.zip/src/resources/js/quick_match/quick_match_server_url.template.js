// Set the following to proper server URL,
// and rename this file to "quick_match_server_url.js".
export const serverURL = 'http://localhost:3000';
